/*
 * File Name:               User.hpp
 * Course:                  ENSF 614 - Fall 2021
 * Lab # and Assignment #:  Lab 7 Exercise C
 * Lab section:             B01
 * Completed by:            Aastha Patel, Bhavyai Gupta
 * Submission Date:         November 23, 2021
 */

#include <string>
using namespace std;
#ifndef USER_H
#define USER_H

struct User
{
    string username;
    string password;
};

#endif
